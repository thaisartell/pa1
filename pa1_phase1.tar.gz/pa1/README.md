# Programming Assignment 1: Integer Sum and Average Calculation

## Team Information
1. Team members: Kip Schetnan, Richard Sartell
2. x500: schet076, sarte016
3. Division of tasks: Richard has worked on child.c. Kip has worked on calculator.c/.h.
4. Lab machine used: Richard - Linux Mint computer, Kip - login01

## Design Specifications
[TODO: Add your design details here]

### Phase 1 Design
- Process creation strategy:
- File handling approach:
- Results storage method:

### Phase 2 Design
- Pipe communication strategy:
- Data transmission format:
- Synchronization approach:

## Challenges Faced
[TODO: Document any challenges]

## AI Tools Usage
(Richard) ChatGPT o3: Use as a reference for function arguments (ex: "function definition for fopen"). 

## Additional Notes
[TODO: Any other information for the TA]
