# Programming Assignment 1: Integer Sum and Average Calculation

## Team Information
1. Team members: [TODO: Add team member names]
2. x500: [TODO: Add x500 IDs]
3. Division of tasks: [TODO: Describe task division]
4. Lab machine used: [TODO: Specify lab machine]

## Design Specifications
[TODO: Add your design details here]

### Phase 1 Design
- Process creation strategy:
- File handling approach:
- Results storage method:

### Phase 2 Design
- Pipe communication strategy:
- Data transmission format:
- Synchronization approach:

## Challenges Faced
[TODO: Document any challenges]

## AI Tools Usage
[TODO: Document any AI tools used]

## Additional Notes
[TODO: Any other information for the TA]
